<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FilosTrack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" href="Filostrack.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
<link rel="icon" 
      type="image/png" 
      href="FilosTrack-logos_transparent.png" />

</head>
<body>
    <nav class="navbar fixed-top navbar navbar-expand-lg navbar-dark bg-dark" id="navigation">
        
    <a class="navbar-brand mb-0 h1" href="#">
      <img src="0.png" width="400" height="400" class="align-text-top">
      <div class="container">
    </a>
    
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="">Home</a>
                <a class='nav-link' href="MyFriends.html">My Friends</a>
                <a class='nav-link' href="AddFriends.html">Add Friend</a>
                <a class='nav-link' href="evocalender.html">Meeting</a>
                <a class='nav-link' href="Science.html">Science</a>
                <a class='nav-link' href="rombus.html">About Us</a>
            </li>
            </ul>
 
    
    <form class="d-flex">
        <button id="button1"  class="btn btn-outline-success me-2" type="button">Sign Up</button>
        <button id="button2" class="btn btn-outline-success me-2" type="button">Log In</button>
    </form>
</div>
</nav>
<div id="main1">
<header class="page-header gradient">
    <img class="img-fluid" src="background.jpg" alt="" width="100%">
    <h1 id="Header3">Stay in touch with the ones that matter.</h1>
    <p id="paragraph1">Do you miss close friends who you gradually stopped talking to after the pandemic was declared? The complete absence of meet-ups and <br> public gatherings during the pandemic has broken many <br> friendships. People have stopped talking to their <br> friends and have grown apart.</p>
    <a href="#header6" class="btn btn-success" role="button" id="button5">How We Combat This</a>

</div>
    <!-- <header class="page-header gradient">
        <div class="row">
            <div class="col-md-6">
                <h2 id="heading2">Stay in touch with the ones that matter.</h2>
                <p id="paragraph1">Do you miss close friends who you gradually stopped talking to after the pandemic was declared? The complete absence of meet-ups and public gatherings during the pandemic has broken many friendships. People have stopped talking to their friends and have grown apart.</p>

                   <p id="paragraph2"> FilosTrack solves this problem with a simple yet elegant idea. Our website uses science-based algorithms and user data to help users maintain and track their relationships. FilosTrack tells you when to contact your friends, keeps track of how often you talk to them and has many more features coming soon.</p>
                   <button type="button" class="btn btn-success" id="button5">Join Us Today</button>

            </div>
        <div class="col-md-6">
            <img class="float-end img-thumbnail" src="https://preview.pixlr.com/images/800wm/100/2/100204204.jpg" alt="">
        </div>
    </div>

        </div>
    </header> -->
    <div id="section2">
        <h1 id="header5">Why do we need friends?</h1>
        <p id="paragraph5">Friends bring more happiness into our lives than virtually anything else. Friendships have a huge impact on your mental health and happiness. Good friends relieve stress, provide comfort and joy, and prevent loneliness and isolation. Developing close friendships can also have a powerful impact on your physical health.</p>
        <img id="image4" src="Team success _Outline.png" alt="Image Failed To Load">
    </div>
    <div id="section3">
        <h1 id="header6">How It Works</h1>
        <p id="paragraph10">FilosTrack helps solve the problem of gradually losing friends with a simple yet elegant idea. Our website uses science-based algorithms and user data to help users maintain and track their relationships. FilosTrack tells you when to contact your friends, keeps track of how often you talk to them and has many more features coming soon.</p>
        <img id="image10" src="User interface_Monochromatic.png" alt="">
        <button id="button10" type="button" class="btn btn-success" id="button5">Sign Up Today</button>
    </div>
</body>
</html>