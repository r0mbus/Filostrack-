.navbar-brand img{
    position: absolute;
    margin-left: -60px;
    margin-top: -115px;
}
.nav-link{
    display: inline-flex;
    margin-left: 20px;
    padding-top: 30px;
}
#navigation{
    padding-bottom: 30px;
}
#button1{
    margin-top: 25px;
}
#button2{
    margin-top: 25px;
}
.carousel-item{
    height: 100%;
    background: #99ccff;
    width: 100%;
}
#Header1{
    margin-top: -430px;
    font-size: 100px;
}
#Header2{
    margin-top: -450px;
    font-size: 60px;
}
#paragraph1{
    margin-top: 40px;
    font-size: 20px;
}
#header3{
    margin-top: -450px;
    font-size: 60px;

}
#paragraph2{
    margin-top: 40px;
    font-size: 20px;
}
#header4{
    margin-top: -450px;
    font-size: 60px;
}
#paragraph3{
    margin-top: 40px;
    font-size: 20px;
}
#header5{
    margin-top: -450px;
    font-size: 60px;
}
#paragraph4{
    margin-top: 40px;
    font-size: 20px;
}
#header6{
    margin-top: -450px;
    font-size: 60px;
}
#paragraph5{
    margin-top: 40px;
    font-size: 20px;
}
#header7{
    margin-top: -450px;
    font-size: 60px;
}
#paragraph6{
    margin-top: 40px;
    font-size: 20px;
}
#header8{
    margin-top: -450px;
    font-size: 60px;
}
#paragraph7{
    margin-top: 40px;
    font-size: 20px;
    
}
#header10{
    margin-top: 60px;
    margin-left: 85px;
    font-size: 50px;
}
#paragraph10{
    margin-top: 40px;
    font-size: 25px;
    margin-left: 80px;
    text-align: center;
}
#paragraph11{
    margin-left: 27px;
}
#accordionExample{
    margin-left: 80px;
    margin-top: 40px;
}
.gradient{
    background: white;
}
#button4{
    margin-left: 295px;
    margin-top: 40px;
    padding-top: 10px ;
    padding-bottom: 10px;
    padding-left: 15px;
    padding-right: 15px;
}
#image10{
    margin-right: 20px;
    margin-top: -40px;
    height: 600px;
}
*{
    color: black;
}